#!/bin/sh



check_os() {
  os_type=centos
  rh_file="/etc/redhat-release"
  if grep -qs "Red Hat" "$rh_file"; then
    os_type=rhel
  fi
  if grep -qs "release 7" "$rh_file"; then
    os_ver=7
  elif grep -qs "release 8" "$rh_file"; then
    os_ver=8
    grep -qi stream "$rh_file" && os_ver=8s
    grep -qi rocky "$rh_file" && os_type=rocky
    grep -qi alma "$rh_file" && os_type=alma
  elif grep -qs "Amazon Linux release 2" /etc/system-release; then
    os_type=amzn
    os_ver=2
  else
    os_type=$(lsb_release -si 2>/dev/null)
    [ -z "$os_type" ] && [ -f /etc/os-release ] && os_type=$(. /etc/os-release && printf '%s' "$ID")
    case $os_type in
      [Uu]buntu)
        os_type=ubuntu
        ;;
      [Dd]ebian)
        os_type=debian
        ;;
      [Rr]aspbian)
        os_type=raspbian
        ;;
      *)
        exiterr "This script only supports Ubuntu, Debian, CentOS/RHEL 7/8 and Amazon Linux 2."
        ;;
    esac
    os_ver=$(sed 's/\..*//' /etc/debian_version | tr -dc 'A-Za-z0-9')
    if [ "$os_ver" = "8" ] || [ "$os_ver" = "jessiesid" ]; then
      exiterr "Debian 8 or Ubuntu < 16.04 is not supported."
    fi
    if { [ "$os_ver" = "10" ] || [ "$os_ver" = "11" ]; } && [ ! -e /dev/ppp ]; then
      exiterr "/dev/ppp is missing. Debian 11 or 10 users, see: https://git.io/vpndebian10"
    fi
  fi
}



install_vpn() {
    if [ "$os_type" = "ubuntu" ] || [ "$os_type" = "debian" ] || [ "$os_type" = "raspbian" ]; then
        apt-get --purge remove -y openvpn
        apt-get install -y epel-release
        apt-get update -y
        apt-get install -y openssl lzo pam openssl-devel lzo-devel pam-devel
        apt-get install -y easy-rsa
        apt-get install -y openvpn
        apt-get install -y iptables-services
        apt-get -y install tcl tk expect rsync
    else
        yum remove -y openvpn
        yum install -y epel-release
        yum update -y
        yum install -y openssl lzo pam openssl-devel lzo-devel pam-devel
        yum install -y easy-rsa
        yum install -y openvpn
        yum install -y iptables-services
        yum -y install tcl tk expect rsync
    fi


    sed -i 's/vpn_server_netmask/'$1'/g' server.conf
    mkdir -p /var/log/openvpn/
    mkdir -p /etc/openvpn/server/user
    chown openvpn:openvpn /var/log/openvpn
    /bin/cp -rf /usr/share/easy-rsa/3.0.8 /etc/openvpn/server/easy-rsa
    current_path=$(pwd)
    rm -rf /etc/localtime
    ln -s /usr/share/zoneinfo/Asia/Shanghai /etc/localtime
    yum install -y ntp
    ntpdate us.pool.ntp.org
    cd /etc/openvpn/server/easy-rsa
    echo "yes" | ./easyrsa init-pki
    echo "\n" | ./easyrsa build-ca nopass
    ./easyrsa build-server-full server nopass
    ./easyrsa gen-dh
    openvpn --genkey --secret ta.key
    ./easyrsa build-client-full client nopass
    mkdir -p /etc/openvpn/server
    rm -rf /etc/openvpn/server/ccd
    mkdir -p /etc/openvpn/server/ccd
    echo "" > /etc/openvpn/server/ipp.txt
    echo 11 > /etc/openvpn/server/tag
    /bin/cp -a pki/ca.crt /etc/openvpn/server/
    /bin/cp -a pki/private/server.key /etc/openvpn/server
    /bin/cp -a pki/issued/server.crt /etc/openvpn/server
    /bin/cp -a pki/dh.pem /etc/openvpn/server
    /bin/cp -a ta.key /etc/openvpn/server
    cd $current_path
    mkdir -p /etc/openvpn/server/
    /bin/cp -rf server.conf /etc/openvpn/server/
    mkdir -p /usr/lib/systemd/system/
    /bin/cp -rf openvpn-server.service /usr/lib/systemd/system/
    chmod -R 777 /etc/openvpn/
    chown openvpn:openvpn -R /etc/openvpn/
    systemctl start openvpn-server
    systemctl enable openvpn-server
    default_gateway=$(ip route | grep default | awk '{printf $3}')
    subnet=${default_gateway%.*}
    subnet=${subnet%.*}
    nicName=
    for devEnum in $(ip link show | grep ^[0-9]\\+: | awk -F ' ' {'print $2'})
    do
       devName=${devEnum%:}
       devName=${devName%@*}
       if [ $(ip addr show $devName | grep -c $subnet) -gt 0 ]; then
            nicName=$devName
            break
       fi
    done
    firewall-cmd --permanent --add-masquerade
    firewall-cmd --permanent --add-service=openvpn
    firewall-cmd --permanent --add-port=1194/tcp
    firewall-cmd --permanent --direct --passthrough ipv4 -t nat -A POSTROUTING -s $1/24 -o $nicName -j MASQUERADE
    firewall-cmd --reload
    systemctl stop firewalld
    systemctl disable firewalld
    systemctl mask firewalld
    systemctl enable iptables
    systemctl restart iptables
    iptables -F
    iptables -t nat -A POSTROUTING -s $1/24 -o $nicName -j MASQUERADE
    iptables -I INPUT -p tcp --dport 1194 -j ACCEPT
    iptables -I INPUT -p udp --dport 1194 -j ACCEPT
    iptables -I FORWARD -s $1/24 -j ACCEPT
    iptables -A OUTPUT -p all -j ACCEPT
    iptables -A INPUT -m state --state RELATED,ESTABLISHED -j ACCEPT
    icmps=($(iptables -nvL --line-number | grep icmp-host-prohibited | awk '{print $1}' ))
    for icmp in ${icmps[@]} ; do
      iptables -D FORWARD $icmp
    done
    service iptables save
    systemctl restart iptables
    count=$(cat /etc/sysctl.conf | grep "^net.ipv4.ip_forward" | wc -l)
    if [ $count -gt 0 ]; then
      sed -i 's/net.ipv4.ip_forward.*/net.ipv4.ip_forward=1/g' /etc/sysctl.conf
      sysctl -p
    else
      echo "net.ipv4.ip_forward=1">> /etc/sysctl.conf
      sysctl -p
    fi

    client_info=${current_path}/client_info
    mkdir -p $client_info
    /bin/cp -rf /etc/openvpn/server/easy-rsa/ta.key $client_info/
    /bin/cp -rf /etc/openvpn/server/easy-rsa/pki/private/client.key $client_info/
    /bin/cp -rf /etc/openvpn/server/easy-rsa/pki/issued/client.crt $client_info/
    /bin/cp -rf /etc/openvpn/server/easy-rsa/pki/ca.crt $client_info/

    systemctl restart openvpn-server

    chmod -R 777 $client_info/
    # chown openvpn:openvpn -R $client_info/
    tar -zcvf $client_info.tar.gz -C $current_path client_info/

    echo "=============================================================================================================================="
    echo 'The vpn server has been installed, you can view the vpn client connection information in the "client_info" directory in the current directory.'
    echo "=============================================================================================================================="

}


check_os
install_vpn $1


